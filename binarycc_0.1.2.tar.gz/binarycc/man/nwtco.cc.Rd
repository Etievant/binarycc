\name{nwtco.cc}
\alias{nwtco.cc}
\title{Phase-two sample based on data from the National Wilm's Tumor Study, with exhaustive sampling of the cases}
\usage{
data(nwtco.cc)
}
\format{A data frame with 1147 observations on the following variables
\describe{
\item{\code{id}}{identification number}
\item{\code{X1}}{definitive histology from the NWTSG Pathology Center (1 for favorable, 2 for unfavorable)}
\item{\code{X2}}{disease stage (I, II, III, IV)}
\item{\code{Y}}{relapse status (for no relapse, 1 for relapse)}
\item{\code{strata}}{institutional histology (1 for favorable, 2 for unfavorable)}
\item{\code{n}}{number of subjects in the entire cohort}
\item{\code{strata.n}}{number of subjects in the stratum in the entire cohort}
\item{\code{strata.m}}{number of subjects sampled from the stratum in the cohort}
\item{\code{weights}}{design weight}
}
}
\description{
Case-cohort (i.e., phase-two sample) obtained from the nwtco data set available
in package \code{survival} (viewed as the cohort), with sampling of the subcohort
stratified on institutional histology and exhaustive sampling of the cases}
\references{
Etiévant Lola. (2026) Variance estimation for generalized linear regression with binary outcome when using case-cohort data. Preprint

Breslow Norman E. and Chatterjee Nilanjan. (1999) Design and analysis of two-phase studies with binary outcome applied to Wilms tumour prognosis. \emph{Applied Statistics} 48:457–468
}
\examples{
data(nwtco.cc)

mod.casecohort <- glm(Y ~ X1 * factor(X2), family = binomial(link = "logit"), data = nwtco.cc, weights = weights, x = TRUE)
est.casecohort  <- influences.glm(mod = mod.casecohort)
variance(casecohort = nwtco.cc, infl = est.casecohort$infl.beta, stratified = TRUE)
}
