\docType{package}
\name{binarycc-package}
\alias{binarycc-package}
\title{The 'binarycc' package.}
\description{
Influence-Based Variance Estimation for Log-Linear and Logistic Regression on Case-Cohort Data.
}
\references{
Etiévant Lola. (2026) Variance estimation for generalized linear regression with binary outcome when using case-cohort data. Preprint
}
