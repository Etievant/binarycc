\name{variance}
\alias{variance}
\title{Influences from glmgee output with log or logit link}
\usage{
variance(casecohort, infl, stratified)
}
\arguments{
\item{casecohort}{data frame with \code{id} (identification), \code{weights} (design weights), and \code{Y} (binary outcome status) for each individual in the phase-two data. If argument \code{stratified} below is set to \code{FALSE}, it should also contain \code{m} (subcohort size) and \code{n} (cohort size). If argument \code{stratified} below is set to \code{TRUE}, it should also contain \code{strata} (strata indicator), \code{strata.m} (subcohort or phase-two sample strata size), \code{strata.n} (cohort strata size), and \code{n} (cohort size).}
\item{infl}{data frame with the influences on the parameter estimates.}
\item{stratified}{was sampling stratified? If \code{stratified} is set to \code{FALSE} then it is assumed that all the cases in the cohort have been sampled (i.e., exhaustive sampling of the cases). Default is \code{FALSE}.}
}
\value{
\describe{
\item{\code{variance}}{vector with the variance estimates.}
}
}
\description{
Computes the influence-based variance estimate that follows the complete
variance decomposition. This function can be used with phase-two data obtained
from the design with unstratified sampling of the subcohort or stratified sampling
based on some covariate and exhaustive sampling of cases, or under the design
with stratified sampling based on case status and possibly some covariate.}
\references{
Etiévant Lola. (2026) Variance estimation for generalized linear regression with binary outcome when using case-cohort data. Preprint
}
\seealso{
  \code{\link{influences.gee}}, \code{\link{influences.glm}}.
}
\examples{
library(glmtoolbox)
data(nwtco.cc)

# using the output from glmgee
mod.casecohort <- glmgee(Y ~ X1 * factor(X2), family = binomial(link = "logit"),
data = nwtco.cc, weights = weights)
est.casecohort <- influences.gee(mod = mod.casecohort, X = model.matrix(mod.casecohort))
variance(casecohort = nwtco.cc, infl = est.casecohort$infl.beta, stratified = TRUE)

# using the output from glm
mod.casecohort <- glm(Y ~ X1 * factor(X2), family = binomial(link = "logit"),
data = nwtco.cc, weights = weights, x = TRUE)
est.casecohort  <- influences.glm(mod = mod.casecohort)
variance(casecohort = nwtco.cc, infl = est.casecohort$infl.beta, stratified = TRUE)
}
