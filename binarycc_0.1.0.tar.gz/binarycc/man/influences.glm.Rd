\name{influences.glm}
\alias{influences.glm}
\title{Influences from glm output with log or logit link}
\usage{
influences.glm(mod)
}
\arguments{
\item{mod}{an object, as returned by function \code{\link{glm}}, with \code{binomial(link = "logit")} or \code{binomial(link = "log")} used for the \code{\link{family}} argument.}
}
\value{
\describe{
\item{\code{beta.hat}}{vector with the parameter estimates obtained from the \code{\link{glm}} function.}
\item{\code{infl.beta}}{data frame with the influences on the parameter estimates.}
\item{\code{link}}{link used in function \code{\link{glm}}, \code{"logit"} or \code{"log"}.}
}
}
\description{
Computes the influences on the beta parameter estimates in a log-linear or
logistic regression model, when the parameter has been estimated with the glm
function. This function can be used on phase-two data obtained from the design
with unstratified sampling of the subcohort or stratified sampling based on some
covariate and exhaustive sampling of cases, or under the design with stratified
sampling based on case status and possibly some covariate.}
\references{
Etiévant Lola. (2026) Variance estimation for generalized linear regression with binary outcome when using case-cohort data. Preprint
}
\seealso{
  \code{\link{variance}}.
}
\examples{
data(nwtco.cc)

mod.casecohort <- glm(Y ~ X1 * factor(X2), family = binomial(link = "logit"), data = nwtco.cc, weights = weights, x = TRUE)
est.casecohort  <- influences.glm(mod = mod.casecohort)
variance(casecohort = nwtco.cc, infl = est.casecohort$infl.beta, stratified = TRUE)
}
