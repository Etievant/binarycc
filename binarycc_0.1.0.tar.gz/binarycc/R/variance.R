variance <- function(casecohort, infl, stratified = FALSE) {

  if (is.null(casecohort$weights)) {
    print("the subjects' weights must be provided")
    return(NULL)
  }
  if (is.null(casecohort$Y)) {
    print("the subjects' binary outcome status must be provided")
    return(NULL)
  }
  if (nrow(casecohort) != nrow(infl)) {
    print("the influences for all the subjects in the case-cohort must be
          provided")}
  if (is.null(casecohort$n)) {
    print("the cohort size must be provided")
    return(NULL)
  }

  if (stratified == FALSE) {
    if (is.null(casecohort$m)) {
      print("the subcohort size must be provided")
      return(NULL)
    }
    casecohort.noncases   <- which(casecohort$Y == 0)
    casecohort.n.noncases <- length(casecohort.noncases)
    m                     <- casecohort$m[1]
    n                     <- casecohort$n[1]
    m.n                   <- m / n

    Product.sigma.w  <- matrix(1 - m.n * (n - 1) / (m - 1),
                               nrow = casecohort.n.noncases,
                               ncol = casecohort.n.noncases)
    diag(Product.sigma.w) <- 1 - m.n

    phase1.var  <- n / (n - 1) * crossprod((infl / sqrt(casecohort$weights)))
    phase2.var  <- t(infl[casecohort.noncases,]) %*% Product.sigma.w %*% infl[casecohort.noncases,]
    var         <- diag(phase1.var + phase2.var)
  } else {
    if (is.null(casecohort$strata.n) | is.null(casecohort$strata.m)) {
      print("the strata size in the cohort and in the subcohort or phase-two
            sample must be provided")
      return(NULL)
    }
    if (is.null(casecohort$strata)) {
      print("the subjects' strata indicator must be provided")
      return(NULL)
    }
    casecohort.n            <- nrow(casecohort)
    n                       <- casecohort$n[1]
    casecohort.Y            <- casecohort$Y
    casecohort.strata       <- casecohort$strata
    casecohort.strata.m     <- casecohort$strata.m
    casecohort.strata.n     <- casecohort$strata.n
    casecohort.strata.m.n   <- casecohort.strata.m / casecohort.strata.n
    casecohort.weights      <- casecohort$weights

    product.sigma.w <- function (indiv) {
      return((casecohort.weights[indiv] != 1) *
               (casecohort.strata == casecohort.strata[indiv]) *
               (casecohort.Y[indiv] == casecohort.Y) *
               (1 - casecohort.strata.m.n *
                  (casecohort.strata.n - 1) / (casecohort.strata.m - 1)))
    }
    Product.sigma.w       <- do.call(rbind, lapply(1:casecohort.n, product.sigma.w))
    diag(Product.sigma.w) <- 1 - 1 / casecohort.weights
    Product.sigma.w[which(is.na(Product.sigma.w))] <- 0

    phase1.var  <-  n / (n - 1) * crossprod((infl / sqrt(casecohort.weights)))
    phase2.var  <- t(infl) %*% Product.sigma.w %*% infl
    var         <- diag(phase1.var + phase2.var)
  }
  return(variance = var)
}
