influences.glm  <- function(mod) {
  X           <- mod$x
  Y           <- mod$y
  q           <- ncol(X)
  n           <- nrow(X)
  weights     <- mod$prior.weights

  beta.hat    <- mod$coefficients
  X.weight    <- weights * X

  link        <- mod$family$link

  if(link == "log"){
    p.hat               <- mod$fitted.values
    XYp.weight          <- (Y - 1) * p.hat / (1 - p.hat)^2  * X.weight
    XXYp.weight         <- array(NA, dim = c(q, q, n))
    for(i in 1:n) { XXYp.weight[,,i] <- tcrossprod(XYp.weight[i,], X[i,]) }
    sum.XXYp.weight     <- apply(X = XXYp.weight, MARGIN = c(1,2), FUN = sum)
    sum.XXYp.weight.inv <- solve(sum.XXYp.weight)
    infl.beta <- ((p.hat - Y) / (1 - p.hat) * X.weight) %*% sum.XXYp.weight.inv
  }

  if(link == "logit"){
    cl.hat        <- mod$linear.predictors
    p.hat         <- sigmoid(cl.hat)
    p1p.hat       <- p.hat * (1 - p.hat)
    XX.weight     <- array(NA, dim = c(q, q, n))
    for(i in 1:n) { XX.weight[,,i] <- p1p.hat[i] * tcrossprod(X.weight[i,], X[i,]) }
    sum.XXp.weight      <- apply(X = XX.weight, MARGIN = c(1,2), FUN = sum)
    sum.XXp.weight.inv  <- solve(sum.XXp.weight)
    infl.beta           <- ((p.hat - Y) * X.weight) %*% sum.XXp.weight.inv
  }
  colnames(infl.beta) <- names(beta.hat)
  return(list(beta.hat = beta.hat, infl.beta = infl.beta, link = link))
}
